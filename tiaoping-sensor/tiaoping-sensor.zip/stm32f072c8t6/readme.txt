我的 3D打印机称重热床传感器 开源项目
https://oshwhub.com/cxg01/3d-printer-weighing-hot-bed-sensor