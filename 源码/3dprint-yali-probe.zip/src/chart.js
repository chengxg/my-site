/**
 * echarts图表. 高性能显示, 亿级数据展示, 500Kb/s实时数据更新
 * 缩放优化, 鼠标滚轮放大缩小, shift键只放大y轴, 不按shift键放大x轴
 * @author b站-仁泉之子
 * @brief
 * @version 1
 * @date 2025-03-15
 *
 * @copyright Copyright (c) 2025
 */
import * as echarts from 'echarts';

export default function useChart() {
  let updateViewTimeId = 0;
  let lastUpdateViewTime = Date.now();
  let chart = null;
  let MaxSenconds = 120; // 显示的最大时间
  let TimeBase = 100 // 每个点的时间间隔us
  let MaxDataBufferSize = MaxSenconds * 1000000 / 5; // 缓存的最大数据量, 1M
  let MaxDataSize = MaxSenconds * 1000000 / TimeBase; // 存储深度, 最大数据量, 60s, 每100us一个数据
  let MaxShowDataSize = 1000; // 窗口显示的最大数据, 数据越大, 页面越卡顿
  const cacheData1 = new Float32Array(MaxDataBufferSize * 4);
  const cacheData2 = new Float32Array(MaxDataBufferSize * 4);
  let dataLength = 0

  let chartOptions = {
    animation: false,
    title: {
      text: '{a|实时数值}  {b|滚轮缩放x轴}  {c|shift+滚轮缩放y轴}',
      textStyle: {
        rich: {
          a: {
            color: '#000',
            fontSize: 20,
          },
          b: {
            color: '#f44336',
            fontSize: 14,
          },
          c: {
            color: '#43a047',
            fontSize: 14,
          },
        }
      },
    },
    // brush: {
    //   toolbox: ['rect', 'keep', 'clear'],
    //   brushType: 'rect', // 默认的刷子类型
    //   throttleDelay: 300, // 刷新延迟
    //   throttleType: 'fixRate', // 节流类型
    // },
    grid: {
      top: 40,
      left: 65,
      right: 40,
      bottom: 70
    },
    animation: false,
    color: ['#ff9800', '#4caf50'],
    tooltip: {
      animation: false,
      trigger: 'axis',
      alwaysShowContent: false, // 始终显示 tooltip
      axisPointer: {
        axis: 'x',
        type: 'cross',
        snap: true,
        show: true,
        precision: 1,
        label: {
          show: true,
          fontSize: 16,
          formatter: function (params) {
            if (params.axisDimension == 'x') {
              return formatTime(params.value)
            }
            return params.value.toFixed(1)
          }
        },
      },
      valueFormatter: function (value, dataIndex) {
        if (value == null) {
          return ''
        }
        return value
      },
    },
    legend: {
      type: 'plain',
      icon: "rect",
      left: 350,
      align: 'left',
      data: ['ADC', '触发值']
    },
    xAxis: {
      type: 'value',
      splitLine: {
        show: true
      },
      minorTick: {
        show: true
      },
      minorSplitLine: {
        show: true
      },
      min: 0,
      max: MaxDataSize,
      splitNumber: 15,
      axisLabel: {
        color: '#000',
        fontSize: 16,
        margin: 10,
        formatter: function (value, index) {
          return formatTime(value)
        }
      }
    },
    yAxis: {
      type: 'value',
      min: 0,
      max: 4500,
      splitNumber: 8,
      splitLine: {
        show: true
      },
      minorTick: {
        show: true
      },
      minorSplitLine: {
        show: false
      },
      axisLabel: {
        color: '#000',
        fontSize: 16,
      }
    },
    series: [{
      type: 'line',
      large: true, // 启用 large 模式
      name: 'ADC',
      clip: true,
      data: [],
      showSymbol: false,
      symbol: "emptyCircle",
      showAllSymbol: 'auto',
      symbolSize: 6,
    }, {
      type: 'line',
      large: true, // 启用 large 模式
      name: '触发值',
      clip: true,
      data: [],
      showSymbol: false,
      symbol: "emptyCircle",
      showAllSymbol: 'auto',
      symbolSize: 6,
    }],
    dataZoom: [
      {
        id: 'dataZoomX',
        show: true,
        type: 'inside',
        filterMode: 'none',
        xAxisIndex: [0],
        start: 0,
        end: 100,
        zoomOnMouseWheel: false, // 'shift'
        rangeMode: ['value', 'percent'],
      },
      {
        id: 'dataZoomY',
        show: true,
        type: 'inside',
        filterMode: 'none',
        yAxisIndex: [0],
        start: 0,
        end: 100,
        zoomOnMouseWheel: false, //'ctrl',
      },
      // {
      //   id: 'dataZoomY2',
      //   show: true,
      //   type: 'slider',
      //   filterMode: 'none',
      //   yAxisIndex: [0],
      //   start: 0,
      //   end: 100,
      //   zoomOnMouseWheel: false, //'ctrl',
      // },
    ],
  }

  function initChart() {
    let chartDom = document.getElementById('chart')
    if (!chartDom) {
      return
    }
    chart = echarts.init(chartDom);
    chart.setOption(chartOptions);
    window.addEventListener("resize", () => {
      chart.resize()
    })
    chart.on('datazoom', function (params) {
      if (!params.batch) {
        return
      }
      let zoomX = params.batch.find(item => item.dataZoomId == "dataZoomX")
      if (zoomX) {
        updateRangeData(zoomX.start, zoomX.end)
      }
    });
    // chart.on('brushSelected', function (params) {
    //   // {
    //   //   batch: [
    //   //     areas: [
    //   //       {
    //   //         range:[[334,509],[76,162]]
    //   //       }
    //   //     ]
    //   //   ],
    //   //   escapeConnect: undefined,
    //   //   type: "brushselected",
    //   // }
    //   // console.log('brushSelected', params)
    // });
    chart.getZr().on('mousewheel', handleWheel);
    // testAddChartData()
  }

  function testAddChartData() {
    let testAddTimeId = 0
    let isAddData = false
    let startTime = Date.now()
    // 监听空格建, 暂停和开始测试数据
    window.addEventListener("keydown", (e) => {
      if (e.key == " ") {
        if (testAddTimeId) {
          isAddData = false
          clearInterval(testAddTimeId)
          testAddTimeId = 0
          console.log('暂停测试数据, 用时:', (Date.now() - startTime) / 1000, 's')
        } else {
          addTestData()
          isAddData = true
          startTime = Date.now()
        }
      }
    })

    function addTestData() {
      testAddTimeId = setInterval(() => {
        if (!isAddData) {
          return
        }
        let t = Date.now()
        let arr1 = []
        let sinT = Math.sin(t / 100) * 4 + 600
        for (let i = 0; i < 500; i++) {
          // 生成正弦波测试数据, 与时间有关
          arr1.push(Math.random() * 0.5 + 10 + sinT)
        }
        addChartData(arr1, 100, 620)
      }, 50)
    }
  }

  function formatTime(value) {
    value = Math.floor(value * TimeBase)
    let us = value % 1000
    let ms = Math.floor(value / 1000) % 1000
    let s = Math.floor(value / 1000000)
    let str = ""
    if (us != 0) {
      str += us + 'us\n'
    }
    if (ms != 0) {
      str += ms + 'ms\n'
    }
    if (s != 0) {
      str += s + 's'
    }
    return str
  }

  // 优化鼠标滚轮放大
  function handleWheel(event) {
    //按住shift键只放大y轴, 不按shift键放大x轴
    if (event.event.shiftKey) {
      setZoomY(event)
    } else {
      setZoomX(event)
    }
  }

  function setZoomX(event) {
    const delta = event.wheelDelta; // 获取滚轮滚动的距离
    const zoomScale = delta > 0 ? 0.4 : 1 / 0.4; // 定义缩放比例
    const chartOption = chart.getOption();
    const dataZoomOption = chartOption.dataZoom[0];
    const currentStart = dataZoomOption.start;
    const currentEnd = dataZoomOption.end;
    const x = event.offsetX; // 获取鼠标在图表容器内的位置
    let px = chart.convertFromPixel('xAxis', x)  // 转成百分比型式
    let xStart = chartOption.xAxis[0].min
    let xEnd = chartOption.xAxis[0].max
    let percentage = ((px - xStart) / (xEnd - xStart)) * 100
    if (percentage <= currentStart || percentage >= currentEnd) {
      return
    }
    const currentRange = currentEnd - currentStart;
    const newRange = currentRange * zoomScale; // 计算缩放后的新范围
    const leftPercentage = (percentage - currentStart) / currentRange; // 计算左右比例
    // const rightPercentage = (currentRange - percentage) / currentRange;
    // 根据左右比例缩放
    let newStart = percentage - newRange * leftPercentage;
    let newEnd = percentage + newRange - newRange * leftPercentage;
    let rangeSize = Math.floor(newRange * MaxDataSize / 100)
    if (rangeSize < 50) {
      return
    }
    chart.dispatchAction({
      type: 'dataZoom',
      batch: [{
        type: 'dataZoom',
        start: newStart,
        end: newEnd,
        dataZoomId: "dataZoomX"
      }]
    });
  }

  function setZoomY(event) {
    const delta = event.wheelDelta; // 获取滚轮滚动的距离
    const zoomScale = delta > 0 ? 0.6 : 1 / 0.6; // 定义缩放比例
    const chartOption = chart.getOption();
    const dataZoomOption = chartOption.dataZoom[1];
    const currentStart = dataZoomOption.start;
    const currentEnd = dataZoomOption.end;
    const y = event.offsetY; // 获取鼠标在图表容器内的位置
    let py = chart.convertFromPixel('yAxis', y)  // 转成百分比型式
    let yStart = chartOption.yAxis[0].min
    let yEnd = chartOption.yAxis[0].max
    let yLength = yEnd - yStart
    let percentage = ((py - yStart) / yLength) * 100
    if (percentage <= currentStart || percentage >= currentEnd) {
      return
    }
    const currentRange = currentEnd - currentStart;
    const newRange = currentRange * zoomScale; // 计算缩放后的新范围
    const leftPercentage = (percentage - currentStart) / currentRange; // 计算左右比例
    // const rightPercentage = (currentRange - percentage) / currentRange;
    // 根据左右比例缩放
    let newStart = percentage - newRange * leftPercentage;
    let newEnd = percentage + newRange - newRange * leftPercentage;
    let rangeSize = Math.floor(newRange * (yEnd - yStart) / 0.001 / 100)
    if (rangeSize < 10) {
      return
    }
    chart.dispatchAction({
      type: 'dataZoom',
      batch: [{
        type: 'dataZoom',
        start: newStart,
        end: newEnd,
        dataZoomId: "dataZoomY"
      }]
    });
  }

  function getMinMaxSampleData(minX, maxX, intervalNum) {
    return new Promise((resolve, reject) => {
      let arr1 = [];
      let arr2 = [];

      let end = 0
      let minVal = 0
      let maxVal = 0
      let minIdx = 0
      let maxIdx = 0
      let i = 0;
      let j = 0;

      arr1.push([minX, cacheData1[minX]])
      for (i = minX; i < maxX; i += intervalNum) {
        end = Math.min(i + intervalNum, maxX)
        minVal = cacheData1[i]
        maxVal = cacheData1[i]
        minIdx = i
        maxIdx = i

        // Find min and max within this interval
        for (j = i; j < end; j++) {
          if (cacheData1[j] < minVal) {
            minVal = cacheData1[j]
            minIdx = j
          }
          if (cacheData1[j] > maxVal) {
            maxVal = cacheData1[j]
            maxIdx = j
          }
        }

        if (minIdx < maxIdx) {
          arr1.push([minIdx, minVal])
          arr1.push([maxIdx, maxVal])
        } else if (minIdx > maxIdx) {
          arr1.push([maxIdx, maxVal])
          arr1.push([minIdx, minVal])
        } else {
          arr1.push([minIdx, minVal])
        }
        arr2.push([maxIdx, cacheData2[maxIdx]])
      }
      arr1.push([maxX - 1, cacheData1[maxX - 1]])

      resolve([arr1, arr2])
    });
  }

  async function getShowData(mixXPercent, maxXPercent) {
    // 根据zoomX的范围, 获取当前显示的数据
    let minX = Math.floor(mixXPercent * MaxDataSize / 100)
    let maxX = Math.floor(maxXPercent * MaxDataSize / 100)
    let arr1 = []
    let arr2 = []
    let len = dataLength
    if (minX >= len) {
      return [arr1]
    }
    if (maxX >= len) {
      maxX = len
    }
    if (minX < 0) {
      minX = 0
    }
    let intervalNum = Math.floor((maxX - minX) / MaxShowDataSize)
    if (intervalNum <= 1) {
      for (let i = minX; i < maxX; i++) {
        arr1.push([i, cacheData1[i]])
        arr2.push([i, cacheData2[i]])
      }
    } else {
      let data = await getMinMaxSampleData(minX, maxX, intervalNum)
      arr1 = data[0]
      arr2 = data[1]
    }
    return [arr1, arr2]
  }

  async function updateRangeData(start, end) {
    let [arr1, arr2] = await getShowData(start, end)
    chart.setOption({
      series: [
        {
          data: arr1
        },
        {
          data: arr2
        }
      ],
      dataZoom: [{
        start: start,
        end: end,
      }]
    })
  }

  function throttleUpdateData() {
    let t = Date.now()
    if (t - lastUpdateViewTime > 300) {
      clearTimeout(updateViewTimeId)
      lastUpdateViewTime = t
      updateChartView()
    } else {
      clearTimeout(updateViewTimeId)
      updateViewTimeId = setTimeout(() => {
        lastUpdateViewTime = t
        updateChartView()
      }, 300)
    }
  }

  function updateChartView() {
    if (!chart) {
      return
    }
    let option = chart.getOption()
    let zoomX = option.dataZoom[0]
    updateRangeData(zoomX.start, zoomX.end)
  }

  function clearChart() {
    dataLength = 0
    MaxDataSize = MaxSenconds * 1000000 / TimeBase
    setTimeout(() => {
      chart.setOption({
        xAxis: {
          min: 0,
          max: MaxDataSize,
        }
      })
    }, 20)
    throttleUpdateData()
  }

  function addChartData(dataArr, time) {
    // 赋值到js变量里
    let i = 1;
    let size = dataArr[i++];
    let triggerValue = (dataArr[i++] << 8) + dataArr[i++];
    if (time != TimeBase || (dataLength + size) > MaxDataSize) {
      TimeBase = time
      clearChart()
    }
    for (let j = 0; j < size; j++) {
      cacheData1[dataLength] = (dataArr[i++] << 8) + dataArr[i++]
      cacheData2[dataLength] = triggerValue
      dataLength++
    }
    throttleUpdateData()
  }

  return {
    initChart,
    addChartData,
    clearChart,
    getChartData() {
      let cacheData1Arr = new Array(dataLength)
      let cacheData2Arr = new Array(dataLength)
      for (let i = 0; i < dataLength; i++) {
        cacheData1Arr[i] = cacheData1[i]
        cacheData2Arr[i] = cacheData2[i]
      }
      return {
        TimeBase,
        MaxDataSize,
        cacheData1: cacheData1Arr,
        cacheData2: cacheData2Arr,
      }
    },
    setChartData(data) {
      clearTimeout(updateViewTimeId)
      TimeBase = data.TimeBase
      MaxDataSize = MaxSenconds * 1000000 / TimeBase
      let len = data.cacheData1.length
      for (let i = 0; i < len; i++) {
        cacheData1[i] = data.cacheData1[i]
        cacheData2[i] = data.cacheData2[i]
      }
      dataLength = len
      chart.setOption({
        xAxis: {
          min: 0,
          max: MaxDataSize,
        }
      })
      updateChartView()
    },
    destoryChart() {
      if (chart) {
        chart.dispose()
        chart = null
      }
      clearTimeout(updateViewTimeId)
    }
  }
}