import { reactive } from 'vue'

export function useSerial() {
  let port = null;
  let writer = null;
  let reader = null;
  let readDataCallback = null; // 读取数据回调
  let serialOpenCallback = null; // 串口打开回调

  let serial = reactive({
    name: "",
    baudRate: 2000000,
    dataBits: 8, // 7 or 8
    stopBits: 1, // 1 or 2
    parity: "none", // "none", "even", "odd
    bufferSize: 1024 * 1024,
    state: "", // closed, opening, opened
    suport: "serial" in navigator,
    open: false, // 串口是否打开
    stop: false, // 是否停止读取数据
  })

  let serialOptions = reactive({
    baudRateOptions: [
      { label: 500000, value: 500000 },
      { label: 1000000, value: 1000000 },
      { label: 2000000, value: 2000000 },
      { label: 2500000, value: 2500000 },
    ],
    dataBitsOptions: [
      { label: 7, value: 7 },
      { label: 8, value: 8 },
    ],
    stopBitsOptions: [
      { label: 1, value: 1 },
      { label: 2, value: 2 },
    ],
    parityOptions: [
      { label: "无", value: "none" },
      { label: "奇", value: "even" },
      { label: "偶", value: "odd" },
    ],
  })

  async function initPort() {
    let cacheCOMInfo = localStorage.getItem("COMInfo_8zhuban")
    if (cacheCOMInfo) {
      let cacheCOMInfoObj = JSON.parse(cacheCOMInfo)
      serial.name = cacheCOMInfoObj.name
      serial.dataBits = cacheCOMInfoObj.dataBits
      serial.stopBits = cacheCOMInfoObj.stopBits
      serial.parity = cacheCOMInfoObj.parity
    }
  }

  function saveCOMInfo() {
    let cacheCOMInfo = {
      name: serial.name,
      baudRate: serial.baudRate,
      dataBits: serial.dataBits,
      stopBits: serial.stopBits,
      parity: serial.parity,
      bufferSize: serial.bufferSize
    }
    localStorage.setItem("COMInfo_8zhuban", JSON.stringify(cacheCOMInfo))
  }

  if (navigator.serial) {
    navigator.serial.onconnect = (event) => {

    };
    navigator.serial.ondisconnect = (event) => {
      closePort()
    };
  }

  async function openPort(isReOpen = true) {
    if (!("serial" in navigator)) {
      return
    }
    if (!port || isReOpen) {
      // 获取用户之前授予该网站访问权限的所有串口。
      port = await navigator.serial.requestPort();
    }

    // 等待串口打开
    await port.open({
      baudRate: serial.baudRate,
      dataBits: serial.dataBits,
      stopBits: serial.stopBits,
      parity: serial.parity,
      bufferSize: serial.bufferSize,
    });
    writer = await port.writable.getWriter()
    reader = await port.readable.getReader()

    serial.open = true
    serial.stop = false
    saveCOMInfo()
    serialOpenCallback && serialOpenCallback()
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          writer.releaseLock();
          reader.releaseLock();
          break;
        }
        if (!serial.stop) {
          readDataCallback && readDataCallback(value)
        }
      }
    } catch (error) {
      console.log(error)
    } finally {
      writer.releaseLock();
      reader.releaseLock();
    }
  }

  function setReadDataCallback(callback) {
    readDataCallback = callback
  }

  function setSerialOpenCallback(callback) {
    serialOpenCallback = callback
  }

  async function closePort() {
    if (port) {
      serial.open = false;
      serial.stop = true;
      try {
        await writer.abort();
        await reader.cancel();
        await port.close();
      } catch (error) {
        console.log(error);
      } finally {
        writer.releaseLock();
        reader.releaseLock();
      }
    }
  }

  function serialWriteData(data) {
    if (writer) {
      writer.write(data)
    }
  }

  function serialToggleStop() {
    serial.stop = !serial.stop
  }

  return {
    serial,
    serialOptions,
    initPort,
    openPort,
    closePort,
    serialWriteData,
    serialToggleStop,
    setReadDataCallback,
    setSerialOpenCallback
  }
}

export function useMyCommand() {
  let command = {
    Start1: 0xf2,
    Start2: 0xf3,
    End1: 0xe2,
    End2: 0xe3,
    isStart: false,
    count: 0,
    bufferSize: 255,
    buffer: new Array(255),
  }
  let commandCallback = null;

  function addCommandData(tempData) {
    if (!command.isStart) {
      if (command.count == 0 && tempData != command.Start1) {
        return;
      }
      command.count++;
      if (command.count == 2) {
        if (command.Start2 == tempData) {
          command.isStart = true;
          command.count = 0;
        } else {
          command.count = 0;
          if (tempData == command.Start1) {
            command.count++;
          }
        }
      }
      if (command.count > 2) {
        command.count = 0;
        command.isStart = false;
      }
      return;
    }
    if (command.count > 64 || command.count >= command.bufferSize) {
      command.count = 0;
      command.isStart = false;
      return;
    }

    command.buffer[command.count] = tempData;
    command.count++;

    if (command.isStart && command.count >= 4) {
      // 检测结束
      if (tempData == command.End2 && command.buffer[command.count - 2] == command.End1) {
        // 长度位
        if (command.buffer[command.count - 3] == command.count - 3) {
          // 校验和
          let checkSum = getCheckSum(command.buffer, 0, command.count - 4);
          // console.log("checkSum:", checkSum, command.buffer[command.count - 4])
          // let arr = []
          // for (let i = 0; i < command.count; i++) {
          //   arr.push(command.buffer[i])
          // }
          // console.log("接收到数据:", arr.join("+"))
          if (checkSum == command.buffer[command.count - 4]) {
            if (typeof commandCallback == "function") {
              commandCallback(command.buffer, command.count);
            }
          }
          // if (typeof commandCallback == "function") {
          //   commandCallback(command.buffer, command.count);
          // }
          command.isStart = false;
          command.count = 0;
        }
      }
    }
  }

  function getCheckSum(buffer, start, end) {
    let i = 0;
    let sum = 0;
    for (i = start; i < end; i++) {
      sum += buffer[i];
    }
    return sum % 256;
  }

  function createdCommandData(dataArr) {
    let len = dataArr.length;
    let buffer = new Uint8Array(len + 6);
    let i = 0;
    buffer[i++] = command.Start1;
    buffer[i++] = command.Start2;
    for (let j = 0; j < len; j++) {
      buffer[i++] = dataArr[j];
    }
    buffer[i++] = getCheckSum(buffer, 2, i)
    buffer[i] = i - 2;
    i++;
    buffer[i++] = command.End1;
    buffer[i++] = command.End2;
    return buffer;
  }

  function setResolveCommandCallback(callback) {
    commandCallback = callback
  }

  return {
    addCommandData,
    createdCommandData,
    setResolveCommandCallback
  }
}