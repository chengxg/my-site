import { createApp } from 'vue'
import {
  Button,
  Modal,
  Popover,
  Tooltip,
  Dropdown,
  Select,
  Input,
  InputNumber,
  Menu,
  Upload,
  Image,
  Alert,
  Switch,
  ConfigProvider,
} from 'ant-design-vue';
import './css/index.less';
import App from './App.vue'

const app = createApp(App)

app.use(Button)
app.use(Modal)
app.use(Popover)
app.use(Tooltip)
app.use(Dropdown)
app.use(Select)
app.use(Input)
app.use(InputNumber)
app.use(Menu)
app.use(Upload)
app.use(Image)
app.use(Alert)
app.use(Switch)
app.use(ConfigProvider)

app.mount('#app')