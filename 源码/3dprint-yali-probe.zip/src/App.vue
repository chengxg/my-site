<template>
  <a-config-provider :locale="zhCN" :getPopupContainer="getPopupContainer">
    <div class="left-content">
      <div style="font-size: 18px;font-weight: bold;text-align: center;color: #512da8;margin-bottom: 18px;">3d打印压力调平传感器</div>
      <div class="form-item">
        <div class="form-item-lable">
          串口连接
        </div>
        <div class="form-item-cnt">
          <a-popover title="串口连接" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                支持谷歌浏览器最新版<br>
              </div>
            </template>
            <a-button class="btn-icon" style="width: 100%;" type="primary" :danger="serial.open" @click="serialToggleOpen">
              {{ serial.open ? "关闭" : "打开" }}
            </a-button>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          波特率
        </div>
        <div class="form-item-cnt">
          <a-popover title="波特率" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                波特率越高, 传输速度越快, 默认2M<br>
                CH340, CH343等USB转串口在高波特率下, 容易导致电脑蓝屏<br>
                目前使用AI8H2K12U实现的USB转串口, 实测2M波特率稳定传输, 而且不会导致电脑蓝屏<br>
              </div>
            </template>
            <a-select disabled :value="serial.baudRate" style="width: 100%;" @change="commandMethods.updateUart1Baud">
              <a-select-option v-for="item in serialOptions.baudRateOptions" :key="item.value" :value="item.value">{{ item.label }}</a-select-option>
            </a-select>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          延时重启
        </div>
        <div class="form-item-cnt">
          <a-popover title="延时重启" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                当使用stc isp下载程序时, 需要重启单片机复位才能下载程序<br>
                可以先点这个按钮重启下, 会延时10s自动重启单片机<br>
              </div>
            </template>
            <a-button class="btn-icon" style="width: 100%;" type="primary" @click="commandMethods.rebootChip">
              重启单片机
            </a-button>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          触发阈值
        </div>
        <div class="form-item-cnt">
          <a-popover title="设置触发阈值" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                指的是静止状态下, 需要变化多少数值才能触发<br>
                数值越大, 需要触发力度越大, 不容易误触发<br>
                数值越小, 需要触发力度越小, 但是容易误触发<br><br>
              </div>
              <a-input-number v-model:value="state.inputTrigValue" @change="updateMethods.updateParams" style="width: 100%;" :min="6" :max="1000">
              </a-input-number>
            </template>
            <div class="item-tag red500">
              {{ state.trigThreshold }}
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          清零偏差
        </div>
        <div class="form-item-cnt">
          <a-popover title="设置自动清零偏差" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                指的是检测热床静止时, 数据的波动小于这个数值就自动校准比较值<br>
                自动清零的波动值, 一定时间内小于这个数值就会自动清零<br><br>
              </div>
              <a-input-number v-model:value="state.inputCalibrationError" @change="updateMethods.updateParams" style="width: 100%;" :min="4"
                :max="150"></a-input-number>
            </template>
            <div class="item-tag brown500">
              {{ state.calibrationError }}
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          触发方向
        </div>
        <div class="form-item-cnt">
          <a-popover title="触发方向" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                设置触发方向<br>
                受力时数据变大还是变小, 取决于传感器的安装问题, 无法通过交换输入信号线的IN+, IN-来解决<br>
                有可能未安装传感器时, 受力时数据会变大, 但是安装了传感器后, 尤其是上了螺丝之后, 受力时数据会变小<br>
                受力时数据变大, 需要设置为[大于触发值]<br>
                受力时数据变小, 需要设置为[小于触发值]<br>
              </div>
            </template>
            <a-select v-model:value="state.trigDirection" style="width: 100%;" @change="updateMethods.updateParams">
              <a-select-option v-for="item in state.trigDirectionOptions" :key="item.value" :value="item.value">{{ item.label }}</a-select-option>
            </a-select>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          触发输出
        </div>
        <div class="form-item-cnt">
          <a-popover title="触发输出" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                设置触发时输出的电平<br>
                设置为"高电平触发"指的是: 触发时输出高电平,不触发时输出低电平, 对应的klipper配置为: [pin: STOP_PIN]<br>
                设置为"低电平触发"指的是: 触发时输出低电平,不触发时输出高电平, 对应的klipper配置为: [pin: !STOP_PIN]<br>
                最好设置为常闭形式
              </div>
            </template>
            <a-select v-model:value="state.outputDirection" style="width: 100%;" @change="updateMethods.updateParams">
              <a-select-option v-for="item in state.outputDirectionOptions" :key="item.value" :value="item.value">{{ item.label }}</a-select-option>
            </a-select>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          使能控制
        </div>
        <div class="form-item-cnt">
          <a-popover title="使能控制" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                设置使能probe<br>
                <div>
                  使能控制: <a-switch v-model:checked="state.inputEnableActivatePin" @change="updateMethods.updateConfigParams2" />
                </div>
                <div>
                  极限保护值:
                  <a-input-number v-model:value="state.inputActivateProtectValue" @change="updateMethods.updateConfigParams2" style="width: 100%;"
                    :min="state.inputTrigValue" :max="2000"></a-input-number>
                </div>
              </div>
            </template>
            <div class="item-tag gray200" style="justify-content: flex-start;padding-left: 8px;">
              <a-switch :checked="state.enableActivatePin == 1" />
              <div style="margin-left: 12px;" v-if="state.enableActivatePin == 1">{{ state.activateProtectValue }}</div>
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          按钮挡位
        </div>
        <div class="form-item-cnt">
          <a-popover title="设置按钮挡位调节" trigger="hover" placement="right" @open-change="updateConfigInput">
            <template #content>
              <div class="popover-content">
                设置按钮挡位调节大小<br>
                长按按钮1.5s以上进入按钮设置挡位的状态<br>
                每按一次按钮增加一档, 红色LED闪烁几次就表示几档, 1-5档循环设置<br>
                再长按1.5s以上退出按钮设置挡位的状态, 或者等待10s会自动退出设置状态<br>
              </div>
              <table class="input-table">
                <thead>
                  <tr>
                    <th class="back-th" style="width: 20%;">挡位/数值</th>
                    <th class="back-th" style="width: 16%;">挡位1</th>
                    <th class="back-th" style="width: 16%;">挡位2</th>
                    <th class="back-th" style="width: 16%;">挡位3</th>
                    <th class="back-th" style="width: 16%;">挡位4</th>
                    <th class="back-th" style="width: 16%;">挡位5</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="back-th">触发值</td>
                    <td v-for="(item, index) in state.inputBtnTrigArr" :key="index">
                      <a-input-number v-model:value="item.threshold" style="width: 100%;" :min="6" :max="1000"
                        @change="updateMethods.updateConfigParams2"></a-input-number>
                    </td>
                  </tr>
                  <tr>
                    <td class="back-th">清零偏差</td>
                    <td v-for="(item, index) in state.inputBtnTrigArr" :key="index">
                      <a-input-number v-model:value="item.calibrationError" style="width: 100%;" :min="6" :max="255"
                        @change="updateMethods.updateConfigParams2"></a-input-number>
                    </td>
                  </tr>
                </tbody>
              </table>
            </template>
            <div class="item-tag gray200" style="flex-direction: column;">
              <div class="item-btntrig">{{ state.btnTrigThresholds }}</div>
              <div class="item-btntrig">{{ state.btnCalibrationErrors }}</div>
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          运行时间
        </div>
        <div class="form-item-cnt">
          <a-popover title="运行时间" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                指的是模块上电到现在的运行时间<br>
              </div>
            </template>
            <div class="item-tag gray200">
              {{ state.formatCurTime }}
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          循环速率
        </div>
        <div class="form-item-cnt">
          <a-popover title="循环速率" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                指的是程序每秒运行的次数, 数值越大, 程序负载越小<br>
                检测是否触发采用定时器中断, 固定为200k/s<br>
              </div>
            </template>
            <div class="item-tag gray200">
              {{ state.loopRate }} k/s
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          最大间隔
        </div>
        <div class="form-item-cnt">
          <a-popover title="最大间隔" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                该程序采用的事件循环实现的, 全程无阻塞式执行<br>
                指的是程序每次循环之间最大的间隔时间<br>
                该数据反应的是程序的响应速度<br>
                有数据收发时, 间隔时间会变大<br>
              </div>
            </template>
            <div class="item-tag gray200" style="color:#333;">
              {{ state.maxLoopTime }} us
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">
          丢包率
        </div>
        <div class="form-item-cnt">
          <a-popover title="丢包率" trigger="hover" placement="right">
            <template #content>
              <div class="popover-content">
                上位机接收数据的丢包率<br>
              </div>
            </template>
            <div class="item-tag gray200" style="color:#333;">
              {{ state.uartLossRate }}
            </div>
          </a-popover>
        </div>
      </div>
      <div class="form-item">
        <div class="form-item-lable">项目地址</div>
        <div class="form-item-cnt">
          <a class="item-tag gray200" target="_blank" style="color: #f44336;" href="https://oshwhub.com/cxg01/3d-printer-weighing-hot-bed-sensor">
            前往
          </a>
        </div>
      </div>
      <div class="form-item" v-if="state.debugInt1 || state.debugInt2">
        debugInt1: {{ state.debugInt1 }}<br>
        debugInt2: {{ state.debugInt2 }}
      </div>
    </div>
    <div class="right-content">
      <div class="sensor-card-list">
        <div class="sensor-card blue-card">
          <div class="card-row">
            <div class="card-info-item">
              <div class="card-title" style="width: 90px;">采样控制</div>
            </div>
            <div class="card-info-item" style="margin-left: 24px;">
              <a-tooltip>
                <template #title>按空格键快读开始和暂停</template>
                <a-button size="small" type="primary" :disabled="!serial.open" :danger="state.isStartSample" @click="updateMethods.updateIsStartSample">
                  {{ state.isStartSample ? "暂停采样" : "开始采样" }}
                </a-button>
              </a-tooltip>
              <a-tooltip>
                <template #title>清空图表数据</template>
                <a-button style="margin-left: 12px;" size="small" type="default" @click="clearChart">
                  清空数据
                </a-button>
              </a-tooltip>
            </div>
            <div class="card-info-item item-btn" style="margin-left: 12px;width: 130px;">
              <a-dropdown>
                <a class="ant-dropdown-link" @click.prevent>
                  采样速率: {{ state.adcSampleIntervalFormat }}
                </a>
                <template #overlay>
                  <a-menu @click="(item) => updateMethods.updateSampleInterval(item.key)">
                    <a-menu-item v-for="item in state.ADCSampleIntervalOptions" :key="item.value">
                      <span :class="{ 'menu-item-active': state.adcSampleInterval == item.value }">{{ item.label }}</span>
                    </a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>
            </div>
            <div class="card-info-item" style="margin-left: 12px;width: 120px;">
              <a-popover title="差值" trigger="hover" placement="bottom">
                <template #content>
                  <div class="popover-content">
                    静止一段时间就会清零<br>
                    清零值=触发值-触发阈值<br>
                  </div>
                </template>
                清零值: {{ state.adcZeroValue }}
              </a-popover>
            </div>
            <div class="card-info-item" style="margin-left: 12px;width: 100px;">
              <a-popover title="差值" trigger="hover" placement="bottom">
                <template #content>
                  <div class="popover-content">
                    当前值与清零值的差<br>
                    清零值=触发值-触发阈值
                    差值=当前值-清零值<br>
                  </div>
                </template>
                差值: {{ state.currentDiffValue }}
              </a-popover>
            </div>
            <div class="card-info-item" style="margin-left: 12px;width: 110px;">
              <a-popover title="极性" trigger="hover" placement="bottom">
                <template #content>
                  <div class="popover-content">
                    传感器实际差分信号的大小, IN+ > IN-为正极性, IN- > IN+为负极性<br>
                    压力床等需要多个传感器并联时, 需要确保所有传感器的极性相同, 否则变化信号会互相抵消<br>
                    改变极性需要调传感器端子的线序, 也就是交换绿线和白线, 或者交换电源红线和黑线<br>
                  </div>
                </template>
                极性: {{ state.adcPolarity == 1 ? "正极性" : "负极性" }}
              </a-popover>
            </div>

            <div class="card-info-item" style="margin-left: 24px;">
              <a-button size="small" type="primary" @click="saveDialog.open">
                导出数据
              </a-button>
              <a-button style="margin-left: 12px;" size="small" type="default" @click="saveDialog.openImportFile">
                导入数据
              </a-button>
              <a-button style="margin-left: 12px;" size="small" type="default" @click="dataDialog.open">
                数据分享
              </a-button>
            </div>
          </div>
        </div>
      </div>
      <div class="chart-wrap">
        <div v-if="!saveDialog.show && saveDialog.title" class="chart-remark" @click="saveDialog.openDetail">
          导入数据: {{ saveDialog.title }}
        </div>
        <div id="chart"></div>
      </div>
    </div>

    <a-modal v-model:open="saveDialog.show" title="导出数据" ok-text="确认" cancel-text="取消" @ok="saveDialog.handleOk">
      <div style="margin-top: 12px;margin-bottom: 12px;position: relative;">
        <div class="input-title">数据标题:</div>
        <a-input v-model:value="saveDialog.title" placeholder="请输入标题" :maxlength="32" style="width: 100%;" />
        <div class="input-title">数据描述:</div>
        <a-textarea v-model:value="saveDialog.remark" placeholder="请输入描述" :maxlength="500" :rows="4" />
        <div class="input-title">添加图片:</div>
        <a-upload :file-list="saveDialog.fileList" action="" accept="image/*" list-type="picture-card" :customRequest="saveDialog.customRequest"
          :before-upload="saveDialog.beforeUpload" @remove="saveDialog.handleRemove" @preview="previewImage.handlePreview">
          <div v-if="saveDialog.fileList.length < 3">
            <PlusOutlined />
            <div style="margin-top: 8px">添加图片</div>
          </div>
        </a-upload>
      </div>
    </a-modal>

    <a-modal v-model:open="saveDialog.detailShow" :footer="null" title="查看数据">
      <div style="margin-top: 12px;margin-bottom: 12px;position: relative;">
        <div class="input-title">数据标题:</div>
        <a-input v-model:value="saveDialog.title" placeholder="请输入标题" :maxlength="32" style="width: 100%;" />
        <div class="input-title">数据描述:</div>
        <a-textarea v-model:value="saveDialog.remark" placeholder="请输入描述" :maxlength="500" :rows="4" />
        <div class="input-title">图片:</div>
        <a-image-preview-group>
          <a-image v-for="(item, index) in saveDialog.fileList" :key="index" :width="120" :src="item.url" />
        </a-image-preview-group>
      </div>
    </a-modal>

    <a-modal v-model:open="dataDialog.show" :footer="null" title="数据分享" :width="690">
      <a-alert message="这里是我的一些数据, 查看更多数据请加qq群" type="warning" />
      <a-input-search style="width: 100%;margin: 12px 0 12px;" v-model:value="dataDialog.searchVal" placeholder="请输入搜索内容" @search="dataDialog.onSearch">
        <template #enterButton>
          <a-button type="primary">搜索</a-button>
        </template>
      </a-input-search>

      <div class="list-wrap">
        <div class="list-item" v-for="(item, index) in dataDialog.list" :key="index">
          <a-spin v-if="item.loading" />
          <div class="list-right-content">
            <div class="list-item-title">
              <div class="title" @click="dataDialog.loadData(item)">{{ item.title }}</div>
              <div class="download-btn" @click="dataDialog.downloadData(item)">
                下载数据
              </div>
            </div>
            <div class="list-item-desc">
              {{ item.desc }}
            </div>
          </div>
        </div>
        <div class="list-item list-item-empty" v-if="dataDialog.list.length == 0">
          没有符合条件的数据
        </div>
      </div>
    </a-modal>

    <div style="position: fixed;width: 0;height: 0;z-index: 10;right: 0;top: 0;">
      <a-image :width="0" :style="{ display: 'none' }" :preview="previewImage" :src="previewImage.src" />
    </div>
  </a-config-provider>
</template>

<script>
import { defineComponent } from "vue"
import APP from "./app.js"

export default defineComponent(APP)
</script>
