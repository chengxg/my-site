/**
 * 3D打印压力调平传感器
 * 
 * @author b站-仁泉之子
 * @brief
 * @version 1
 * @date 2025-04-19
 *
 * @copyright Copyright (c) 2025
 */
import { reactive, onMounted, onUnmounted } from 'vue'
import { message, Modal } from 'ant-design-vue'
import useChart from './chart.js'
import { useSerial, useMyCommand } from './mixin.js'
import PlusOutlined from '@ant-design/icons-vue/lib/icons/PlusOutlined'
import axios from 'axios'
import zhCN from 'ant-design-vue/es/locale/zh_CN';

const hexStrMap = [];
// 8位整数转16进制字符串
function int8ToHexString(num) {
  if (hexStrMap.length == 0) {
    for (let i = 0; i < 256; i++) {
      let iHex = i.toString(16).toUpperCase();
      if (iHex.length == 1) {
        iHex = "0" + iHex;
      }
      hexStrMap[i] = iHex;
    }
  }
  num = Math.floor(num);
  return hexStrMap[num & 0xFF];
}

export default {
  name: "app",
  components: { PlusOutlined },
  setup() {
    let {
      serial,
      serialOptions,
      initPort,
      openPort,
      closePort,
      serialWriteData,
      serialToggleStop,
      setReadDataCallback,
      setSerialOpenCallback,
    } = useSerial()
    let {
      addCommandData,
      createdCommandData,
      setResolveCommandCallback
    } = useMyCommand()
    let { initChart, addChartData, getChartData, setChartData, clearChart, destoryChart } = useChart()
    // 设备状态
    let state = reactive({
      version: 1, // 版本号
      curTime: 0, // 单片机时间 每个计数65536us
      curTimeUs: 0, // 单片机时间 当前定时器0计数值, 1us
      formatCurTime: formatTime(0), // 单片机时间 格式化变成 hh:mm:ss
      sampleChannel: 1, // 采样通道 极性, 正信号和反信号
      adcValue: 0, // ADC值
      adcPolarity: 1, // ADC极性 1:正信号 0:反信号
      compareValue: 0, // 比较值
      trigThreshold: 0, // 触发阈值
      trigDirection: 1, // 信号输出触发方向 1:大于阈值触发 0:小于阈值触发
      outputDirection: 1, // 输出方向 1:触发时输出高电平 0:触发时输出低电平
      calibrationError: 0, // 校准误差
      loopCount: 0, // 一定时间内的循环次数
      maxLoopTime: 0, // 一定时间内的最大单次循环时间 us
      uartSendCount: 0, // 串口字节数量
      debugInt1: 0, // 测试值
      debugInt2: 0, // 测试值

      receiveUartCount: 0, // 接收字节数量
      uartLossRate: "0%", // 串口接收丢包率
      loopRate: "0", // loop循环速率 (curTime - lastTime) / (loopCount - lastLoopCount)
      inputTrigValue: "0", // 临时输入值
      inputSampleChannel: "0", // 临时输入值
      inputCalibrationError: "0", // 临时输入值
      inputTrigDirection: 1, // 临时输入值
      inputOutputDirection: 1, // 临时输入值
      currentDiffValue: 0, // 当前差值
      adcZeroValue: 0, // ADC零点值
      trigDirectionOptions: [
        { label: "大于触发值", value: 1 },
        { label: "小于触发值", value: 0 },
      ],
      outputDirectionOptions: [
        { label: "输出高电平", value: 1 },
        { label: "输出低电平", value: 0 },
      ],
      btnTrigThresholds: [0, 0, 0, 0, 0], // 按钮调节触发阈值
      btnCalibrationErrors: [0, 0, 0, 0, 0], // 按钮挡位对应的校准误差
      enableActivatePin: 0, // 是否启用激活引脚
      activateProtectValue: 0, // 未激活时的限制保护值

      inputBtnTrigArr: [
        { threshold: 0, calibrationError: 0 },
        { threshold: 0, calibrationError: 0 },
        { threshold: 0, calibrationError: 0 },
        { threshold: 0, calibrationError: 0 },
        { threshold: 0, calibrationError: 0 },
      ], // [{threshold:0, calibrationError:0}] 按钮调节触发阈值
      inputEnableActivatePin: 0, // 是否启用激活引脚
      inputActivateProtectValue: 0, // 未激活时的限制保护值

      loading: false,
      triggerSendADCTimeId: 0,
      adcSampleInterval: 0.05, // 每隔多少毫秒采样一次数据
      adcSampleIntervalFormat: '20k/s', // 每隔多少毫秒采样一次数据
      ADCSampleIntervalOptions: [
        { label: "100k/s", value: 0.01 },
        { label: "50k/s", value: 0.02 },
        { label: "20k/s", value: 0.05 },
        { label: "10k/s", value: 0.1 },
        { label: "5k/s", value: 0.2 },
        { label: "2k/s", value: 0.5 },
      ],
      isStartSample: true, // 是否开始采样
      isChangeBaudRate: false, // 是否更改波特率
      changeBaudRateTimeoutId: 0, // 更改波特率超时定时器
    })

    let previewImage = reactive({
      visible: false,
      src: '',
      title: '',
      onVisibleChange(value) {
        previewImage.visible = value;
      },
      handlePreview(file) {
        previewImage.src = file.url;
        previewImage.visible = true;
        previewImage.title = file.name || file.url.substring(file.url.lastIndexOf('/') + 1);
      }
    })

    let saveDialog = reactive({
      show: false,
      detailShow: false,
      title: "",
      remark: "",
      fileList: [], // { uid: '', name: '', status: '', url: ''}
      loading: false,
      open() {
        saveDialog.show = true
      },
      openDetail() {
        saveDialog.detailShow = true
      },
      handleOk() {
        saveDialog.show = false
        saveDialog.exportChartData()
      },
      clearForm() {
        saveDialog.title = ""
        saveDialog.remark = ""
        saveDialog.fileList = []
      },
      getBase64(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result);
          reader.onerror = error => reject(error);
        });
      },
      customRequest(obj) {
        return new Promise((resolve, reject) => {
          saveDialog.getBase64(obj.file).then((base64Url) => {
            saveDialog.fileList.push({
              uid: obj.file.uid,
              name: obj.file.name,
              status: 'done',
              url: base64Url,
            });
            saveDialog.loading = false;
            resolve();
          }).catch((error) => {
            saveDialog.loading = false;
            reject(error);
          });
        });
      },
      beforeUpload(file) {
        const isLt1M = file.size / 1024 / 1024 < 1;
        if (!isLt1M) {
          message.error('图片不能大于1MB!');
        }
        return isLt1M;
      },
      handleRemove(file) {
        const index = saveDialog.fileList.indexOf(file);
        if (index >= 0) {
          saveDialog.fileList.splice(index, 1);
        }
      },
      exportChartData() {
        let data = getChartData()
        Object.assign(data, {
          title: saveDialog.title || "chartData",
          remark: saveDialog.remark,
          fileList: saveDialog.fileList,
        })
        let blob = new Blob([JSON.stringify(data)], { type: "application/json" });
        let url = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.href = url;
        a.download = "chartData.json";
        a.click();
        URL.revokeObjectURL(url);
        a.remove();
        message.success("导出数据成功, 请等待下载!")
        saveDialog.show = false
        saveDialog.clearForm()
      },
      openImportFile() {
        let input = document.createElement("input");
        input.type = "file";
        input.accept = ".json";
        input.style.display = "none";
        input.onchange = function (event) {
          saveDialog.importChartData(event);
        };
        document.body.appendChild(input);
        input.click();
        document.body.removeChild(input);
      },
      // 导入数据
      // 解析json文件, 赋值到图表里
      importChartData(event) {
        let file = event.target.files[0];
        if (!file) {
          return;
        }
        // 先停止采样
        state.isStartSample = false
        commandMethods.updateADCSampleParams()
        let reader = new FileReader();
        reader.onload = function (e) {
          setTimeout(function () {
            try {
              let data = JSON.parse(e.target.result);
              setChartData(data);
              Object.assign(saveDialog, {
                title: data.title,
                remark: data.remark,
                fileList: data.fileList || [],
              });
              state.adcSampleInterval = data.TimeBase / 1000
            } catch (e) {
              message.error("文件解析失败!")
              return
            }
          }, 100)
        }
        reader.readAsText(file);
      },
      setImportData(data) {
        setChartData(data);
        Object.assign(saveDialog, {
          title: data.title,
          remark: data.remark,
          fileList: data.fileList || [],
        });
        state.adcSampleInterval = data.TimeBase / 1000
      }
    })

    let dataDialog = reactive({
      show: false,
      loading: false,
      allList: [],
      list: [], // [{ title: '', url: '', desc:'', loading: false}]
      searchVal: "",
      handleOk() {
        dataDialog.show = false
      },
      onSearch(searchValue) {
        if (searchValue == "") {
          dataDialog.list = dataDialog.allList
          return
        }
        dataDialog.list = dataDialog.allList.filter((item) => {
          return item.title.indexOf(searchValue) != -1 || item.desc.indexOf(searchValue) != -1
        })
      },
      open() {
        dataDialog.show = true
        dataDialog.searchVal = ""
        dataDialog.list = dataDialog.allList
      },
      loadData(row) {
        if (row.loading) {
          return
        }
        row.loading = true
        axios(row.url).then((response) => {
          row.loading = false
          if (response.status == 200) {
            let data = response.data
            saveDialog.setImportData(data)
            message.success("加载数据成功!")
            dataDialog.show = false
          }
        }).catch((error) => {
          message.error("加载数据失败!")
          row.loading = false
        })
      },
      downloadData(row) {
        let blob = new Blob([JSON.stringify(row)], { type: "application/json" });
        let url = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.href = url;
        a.download = row.title + ".json";
        a.click();
        URL.revokeObjectURL(url);
        a.remove();
        message.success("下载数据成功, 请保存!")
      }
    })

    for (let i = 0; i < 20; i++) {
      dataDialog.allList.push({
        title: "压力床test",
        desc: "压力床test1",
        url: "./data/压力床test1.json",
        loading: false,
      })
    }

    let commandMethods = {
      setAutoSyncDeiveStatus() {
        setTimeout(() => {
          commandMethods.getDeviceParams()
        }, 100)
        setTimeout(() => {
          commandMethods.getBtnTrigThresholds()
        }, 150)
        setTimeout(() => {
          commandMethods.updateADCSampleParams()
        }, 200)
        clearInterval(state.triggerSendADCTimeId)
        state.triggerSendADCTimeId = setInterval(() => {
          commandMethods.updateADCSampleParams()
        }, 500)
      },
      rebootChip() {
        if (!serial.open) {
          return
        }
        let buffer = [
          0x06, 0x07,
        ]
        //重启芯片
        let sendBuffer = createdCommandData(buffer)
        serialWriteData(sendBuffer)
      },
      ackRebootChip() {
        message.success("设置重启成功, 10s之后重启复位!")
      },
      updateUart1Baud(baudRate) {
        serial.baudRate = baudRate
        if (!serial.open) {
          return
        }
        if (state.isChangeBaudRate) {
          return
        }
        state.isChangeBaudRate = true
        let originalBaudRate = serial.baudRate
        Modal.confirm({
          title: "提示",
          content: "更改波特率后, 10s之内通信不成功, 将恢复原波特率!",
          okText: '确定',
          cancelText: '取消',
          onCancel() {
            state.isChangeBaudRate = false
          },
          onOk: () => {
            baudRate = Number(baudRate)
            serial.baudRate = baudRate
            let buffer = [
              0x08, 0x09,
              (baudRate & 0xff000000) >> 24,
              (baudRate & 0x00ff0000) >> 16,
              (baudRate & 0x0000ff00) >> 8,
              baudRate & 0x00ff
            ]
            //更改串口1波特率
            let sendBuffer = createdCommandData(buffer)
            serialWriteData(sendBuffer)
            state.changeBaudRateTimeoutId = setTimeout(() => {
              serial.baudRate = originalBaudRate
              closePort()
              setTimeout(() => {
                openPort(false)
                Modal.error({
                  title: '设置失败',
                  content: '设置失败! 已恢复原2M波特率!',
                });
              }, 100)
            }, 10000)
            setTimeout(() => {
              serial.baudRate = baudRate
              closePort()
              setTimeout(() => {
                openPort(false)
              }, 1000)
            }, 50)
          }
        })
      },
      updateADCSampleParams() {
        if (!serial.open) {
          return
        }
        let adcSampleInterval = state.adcSampleInterval * 1000 // us
        if (!state.isStartSample) {
          adcSampleInterval = 0
        }
        let buffer = [
          0x01, 0x02,
          // 发送的时间间隔
          Math.floor(adcSampleInterval / 256),
          adcSampleInterval % 256,
        ]
        //触发自动发送当前值
        // f0 f1 01 02 00 00 05 e0 e1
        let sendBuffer = createdCommandData(buffer)
        serialWriteData(sendBuffer)
      },
      updateADCSample(dataArr) {
        if (!saveDialog.show && saveDialog.title) {
          saveDialog.clearForm()
        }
        // 添加到图表里
        addChartData(dataArr, state.adcSampleInterval * 1000)
      },
      updateDeviceParams(dataArr) {
        let i = 2;
        let version = dataArr[i++];
        let trigThreshold = (dataArr[i++] << 8) + dataArr[i++];
        let sampleChannel = dataArr[i++];
        let calibrationError = (dataArr[i++] << 8) + dataArr[i++];
        let trigDirection = dataArr[i++];
        let outputDirection = dataArr[i++];
        let adcValue = (dataArr[i++] << 8) + dataArr[i++];
        let compareValue = (dataArr[i++] << 8) + dataArr[i++];
        let curTime = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let curTimeUs = (dataArr[i++] << 8) + dataArr[i++];
        let loopCount = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let maxLoopTime = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let uartSendCount = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let debugInt1 = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let debugInt2 = (dataArr[i++] << 24) + (dataArr[i++] << 16) + (dataArr[i++] << 8) + dataArr[i++];
        let adcPolarity = dataArr[i++];

        state.version = version
        state.trigThreshold = trigThreshold
        state.sampleChannel = sampleChannel
        state.calibrationError = calibrationError
        state.trigDirection = trigDirection
        state.outputDirection = outputDirection
        state.adcValue = adcValue
        state.adcPolarity = adcPolarity
        state.compareValue = compareValue
        // Use BigInt to handle large integer calculations, avoiding 32-bit integer limits
        const previousTimeUs = BigInt(state.curTime) * BigInt(65536) + BigInt(state.curTimeUs);
        const currentTimeUs = BigInt(curTime) * BigInt(65536) + BigInt(curTimeUs);
        let timeDiffUs = Number(currentTimeUs - previousTimeUs);
        state.loopRate = ((loopCount - state.loopCount) / (timeDiffUs / 1000)).toFixed(2)
        state.loopCount = loopCount
        state.maxLoopTime = maxLoopTime
        // 通信接收丢包率
        let sendCount = uartSendCount - state.uartSendCount
        let receiveUartCount = state.receiveUartCount
        state.uartLossRate = ((sendCount - receiveUartCount) / sendCount * 100).toFixed(2) + '%'
        state.uartSendCount = uartSendCount

        state.curTime = curTime
        state.curTimeUs = curTimeUs
        state.formatCurTime = formatTime(curTime / (1000 / 65.536))
        state.debugInt1 = debugInt1
        state.debugInt2 = debugInt2

        state.receiveUartCount = 0;
        clearTimeout(state.changeBaudRateTimeoutId)
        state.isChangeBaudRate = false

        if (state.trigDirection == 1) {
          state.currentDiffValue = state.adcValue - (state.compareValue - state.trigThreshold)
          state.adcZeroValue = state.compareValue - state.trigThreshold
        } else {
          state.currentDiffValue = (state.compareValue + state.trigThreshold) - state.adcValue
          state.adcZeroValue = state.compareValue + state.trigThreshold
        }
      },
      writeDeviceParams() {
        if (!serial.open) {
          return
        }
        let inputTrigValue = Math.round(Number(state.inputTrigValue))
        let inputSampleChannel = Number(state.inputSampleChannel)
        let inputCalibrationError = Math.round(Number(state.inputCalibrationError))
        let inputTrigDirection = state.inputTrigDirection * 1
        let inputOutputDirection = state.inputOutputDirection * 1
        if (inputTrigValue < 8) {
          inputTrigValue = 8
        }

        if (inputCalibrationError > (inputTrigValue + inputCalibrationError / 2)) {
          inputCalibrationError = (inputTrigValue + inputCalibrationError / 2)
        }

        let buffer = [0x03, 0x02]
        let i = 2;
        buffer[i++] = 0x01
        buffer[i++] = inputTrigValue >> 8
        buffer[i++] = inputTrigValue & 0xff
        buffer[i++] = inputSampleChannel
        buffer[i++] = inputCalibrationError >> 8
        buffer[i++] = inputCalibrationError & 0xff
        buffer[i++] = inputTrigDirection
        buffer[i++] = inputOutputDirection
        // 设置配置参数
        // f0 f1 03 02 ... e0 e1
        serialWriteData(createdCommandData(buffer))
      },
      getDeviceParams() {
        if (!serial.open) {
          return
        }
        let buffer = [0x02, 0x02]
        // 读取配置参数
        // f0 f1 02 02 ... e0 e1
        serialWriteData(createdCommandData(buffer))
      },
      setBtnTrigThresholds(dataArr) {
        let i = 2;
        let size = dataArr[i++];
        for (let j = 0; j < size; j++) {
          let trigThreshold = (dataArr[i++] << 8) + dataArr[i++];
          let calibrationError = dataArr[i++];
          state.btnTrigThresholds[j] = trigThreshold
          state.btnCalibrationErrors[j] = calibrationError
        }
        state.enableActivatePin = dataArr[i++]
        state.activateProtectValue = (dataArr[i++] << 8) + dataArr[i++];
      },
      getBtnTrigThresholds() {
        if (!serial.open) {
          return
        }
        let buffer = [0x04, 0x02]
        // 获取按钮触发挡位
        serialWriteData(createdCommandData(buffer))
      },
      writeConfigParams2() {
        if (!serial.open) {
          return
        }
        let inputBtnTrigArr = state.inputBtnTrigArr
        let inputEnableActivatePin = state.inputEnableActivatePin
        let inputActivateProtectValue = state.inputActivateProtectValue * 1
        if (inputActivateProtectValue < state.trigThreshold) {
          inputActivateProtectValue = state.trigThreshold
          state.inputActivateProtectValue = inputActivateProtectValue
        }
        if (inputEnableActivatePin === false) {
          inputEnableActivatePin = 0
        }
        if (inputEnableActivatePin === true) {
          inputEnableActivatePin = 1
        }
        let buffer = [0x04, 0x01]
        let i = 2;
        for (let j = 0; j < 5; j++) {
          buffer[i++] = (inputBtnTrigArr[j].threshold * 1) >> 8
          buffer[i++] = (inputBtnTrigArr[j].threshold * 1) & 0xff
          buffer[i++] = inputBtnTrigArr[j].calibrationError * 1
        }
        buffer[i++] = inputEnableActivatePin
        buffer[i++] = inputActivateProtectValue >> 8
        buffer[i++] = inputActivateProtectValue & 0xff
        // 设置按钮触发挡位
        serialWriteData(createdCommandData(buffer))
      }
    }

    let updateMethods = {
      updateIsStartSample() {
        state.isStartSample = !state.isStartSample
        commandMethods.updateADCSampleParams()
      },
      updateSampleInterval(value) {
        state.adcSampleInterval = value
        state.adcSampleIntervalFormat = formatSampleInterval(value)
        commandMethods.updateADCSampleParams()
      },
      updateSampleChannel(value) {
        state.inputSampleChannel = value
        updateMethods.updateParams()
      },
      updateParams() {
        state.inputTrigDirection = state.trigDirection
        state.inputOutputDirection = state.outputDirection
        clearTimeout(state.updateParamsTimeId)
        state.updateParamsTimeId = setTimeout(() => {
          commandMethods.writeDeviceParams()
        }, 300)
      },
      updateConfigParams2() {
        clearTimeout(state.updateParamsTimeId)
        state.updateParamsTimeId = setTimeout(() => {
          commandMethods.writeConfigParams2()
        }, 300)
      }
    }

    function updateConfigInput() {
      state.inputTrigValue = state.trigThreshold
      state.inputCalibrationError = state.calibrationError
      for (let i = 0; i < 5; i++) {
        state.inputBtnTrigArr[i].threshold = state.btnTrigThresholds[i] || 0
        state.inputBtnTrigArr[i].calibrationError = state.btnCalibrationErrors[i] || 0
      }
      if (state.enableActivatePin == 0) {
        state.inputEnableActivatePin = false
      } else {
        state.inputEnableActivatePin = true
      }
      state.inputActivateProtectValue = state.activateProtectValue
    }

    function serialToggleOpen() {
      if (serial.open) {
        closePort()
      } else {
        openPort()
      }
    }

    function formatValue(value, fixed = 1) {
      return Number(value).toFixed(fixed)
    }

    function formatTime(time) {
      time = Math.floor(time)
      let hour = Math.floor(time / 3600)
      let minute = Math.floor((time % 3600) / 60)
      let second = Math.floor(time % 60)
      if (hour < 10) {
        hour = "0" + hour
      }
      if (minute < 10) {
        minute = "0" + minute
      }
      if (second < 10) {
        second = "0" + second
      }
      return `${hour}:${minute}:${second}`
    }

    function formatSampleInterval(time) {
      let item = state.ADCSampleIntervalOptions.find(item => item.value == time)
      if (item) {
        return item.label
      }
      return time + "ms"
    }

    onMounted(() => {
      initPort()
      initChart()
      setSerialOpenCallback(() => {
        commandMethods.setAutoSyncDeiveStatus()
        state.isStartSample = true
      })
      setReadDataCallback((uint8Value) => {
        // let arr = []
        for (let i = 0; i < uint8Value.length; i++) {
          // arr.push(int8ToHexString(uint8Value[i]))
          addCommandData(uint8Value[i])
        }
        // console.log("接收到数据:", arr)
      })
      setResolveCommandCallback((dataArr, length) => {
        state.receiveUartCount++
        // console.log("接收到数据:", dataArr, length)
        // 确认是否是正确的数据
        if (dataArr[0] == 0x01 && dataArr[1] == 0x01) {
          commandMethods.ackRebootChip(dataArr)
        }
        // 当前配置参数
        if (dataArr[0] == 0x02 && dataArr[1] == 0x01) {
          commandMethods.updateDeviceParams(dataArr)
        }
        // 当前ADC读数值
        if (dataArr[0] == 0x20) {
          commandMethods.updateADCSample(dataArr)
        }
        // 读取按钮挡位
        if (dataArr[0] == 0x04 && dataArr[1] == 0x02) {
          commandMethods.setBtnTrigThresholds(dataArr)
        }
      })

      // 监听空格建, 暂停和开始显示波形图
      window.addEventListener("keydown", onkeydown)
    })

    onUnmounted(() => {
      console.log("onUnmounted")
      destoryChart()
      clearInterval(state.triggerSendADCTimeId)
      window.removeEventListener("keydown", onkeydown)
    })

    function onkeydown(e) {
      if (e.key == " ") {
        state.isStartSample = !state.isStartSample
        commandMethods.updateADCSampleParams()
      }
    }

    return {
      serial,
      serialOptions,
      serialToggleStop,
      serialToggleOpen,
      zhCN,
      state,
      previewImage,
      saveDialog,
      dataDialog,
      commandMethods,
      updateMethods,
      formatValue,
      updateConfigInput,
      getPopupContainer: () => document.getElementById("app"),
      clearChart
    }
  },
}